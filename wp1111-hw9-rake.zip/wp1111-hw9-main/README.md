# Web Programming HW#6

完成基本要求

## 如何開啟網站

### Step 1 :

先 "分別" cd 到 hw6, frontend, backend 並執行 yarn install(所以共要 yarn install 3 次)

### Step 2 :

在 hw6 ⽬錄底下執⾏ yarn server 開啟 server，以及在另外⼀個 terminal, 也是在 hw6 ⽬錄底下，⽤ yarn start 開啟前端網⾴
